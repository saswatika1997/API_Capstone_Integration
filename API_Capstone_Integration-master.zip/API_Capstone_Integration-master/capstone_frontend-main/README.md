# react-signup-verification-capstone

React - Email Sign Up with Verification, Authentication & Forgot Password

For run app, Please install npm.