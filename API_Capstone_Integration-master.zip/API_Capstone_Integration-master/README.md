# capstone-content
 Integration and Deployment team repo (IITR FSD).<br>
 Courtesy of [Narayanan](https://github.com/narayanankesavan) and [Anshul](https://github.com/anshulv1401).
