package com.iitr.gl.executeCode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExecuteCodeApplication {

    public static void main(String[] args) {
        SpringApplication.run(ExecuteCodeApplication.class, args);
    }

}
