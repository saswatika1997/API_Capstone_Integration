# microservice-discovery-service
Capstoneproject-Live demo - Automated
