package com.iitr.gl.microservicediscoveryservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceDiscoveryServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
