# microservice-discovery
Automate deployment for spring eureka 
It is for capstone project API-1 -Prod-1
