package com.iitr.gl.userdetailservice.ui.model;

public class UploadPythonScriptResponseModel {
    private String scriptId;
    private String message;

    public String getScriptId() {
        return scriptId;
    }

    public void setScriptId(String scriptId) {
        this.scriptId = scriptId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
