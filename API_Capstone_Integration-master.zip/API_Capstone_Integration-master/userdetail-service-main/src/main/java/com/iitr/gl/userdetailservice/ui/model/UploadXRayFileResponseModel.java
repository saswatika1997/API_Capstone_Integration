package com.iitr.gl.userdetailservice.ui.model;

public class UploadXRayFileResponseModel {
    private String message;
    private String xrayId;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getXrayId() {
        return xrayId;
    }

    public void setXrayId(String xrayId) {
        this.xrayId = xrayId;
    }
}
