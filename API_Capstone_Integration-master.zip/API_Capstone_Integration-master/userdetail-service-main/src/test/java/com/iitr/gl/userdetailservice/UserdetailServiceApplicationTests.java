package com.iitr.gl.userdetailservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserdetailServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
